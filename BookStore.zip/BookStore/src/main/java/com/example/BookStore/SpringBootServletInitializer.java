package com.example.BookStore;

import org.springframework.boot.builder.SpringApplicationBuilder;

public class SpringBootServletInitializer {

	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		// TODO Auto-generated method stub
		return null;
	}

}
